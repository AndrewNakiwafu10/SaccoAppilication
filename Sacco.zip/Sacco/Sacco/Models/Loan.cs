﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Sacco.Models
{
    public class Loan
    {
        public int LoanId { get; set; }
        public Double LoanAmount { get; set; }
        public int Interest { get; set; }
        public int Period { get; set; }

        public int ClientId { get; set; }

        [ForeignKey("ClientId")]
        public Client client { get; set; }


    }
}
