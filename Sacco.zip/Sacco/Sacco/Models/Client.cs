﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sacco.Models
{
    public class Client
    {

        public int ClientID { get; set; }
        public string ClientName { get; set; }
        public DateTime Date { get; set; }
        public Client()
        {

        }

    }
}
