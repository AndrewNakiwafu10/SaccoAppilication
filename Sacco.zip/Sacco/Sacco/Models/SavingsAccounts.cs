﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Sacco.Models
{
    public class SavingsAccounts
    {
        
        public int SavingsAccountsId { get; set; }
        public string savingsAccountName { get; set; }
        public DateTime dateOpened { get; set; }
        public int ClientId { get; set; }

        [ForeignKey("ClientId")]
        public Client client { get; set; }



    }
}
