﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Sacco.Models;

namespace Sacco.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<Sacco.Models.Client> Client { get; set; }
        public DbSet<Sacco.Models.SavingsAccounts> SavingsAccounts { get; set; }
        public DbSet<Sacco.Models.Loan> Loan { get; set; }
    }
}
