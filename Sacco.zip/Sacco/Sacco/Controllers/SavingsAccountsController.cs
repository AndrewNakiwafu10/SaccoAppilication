﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Sacco.Data;
using Sacco.Models;

namespace Sacco.Controllers
{
    public class SavingsAccountsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public SavingsAccountsController(ApplicationDbContext context)
        {
            _context = context;
        }
        
        // GET: SavingsAccounts
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.SavingsAccounts.Include(s => s.client);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: SavingsAccounts/Details/5
        [Authorize]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var savingsAccounts = await _context.SavingsAccounts
                .Include(s => s.client)
                .FirstOrDefaultAsync(m => m.SavingsAccountsId == id);
            if (savingsAccounts == null)
            {
                return NotFound();
            }

            return View(savingsAccounts);
        }

        // GET: SavingsAccounts/Create
        [Authorize]
        public IActionResult Create()
        {
            ViewData["ClientId"] = new SelectList(_context.Client, "ClientID", "ClientID");
            return View();
        }

        // POST: SavingsAccounts/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("SavingsAccountsId,savingsAccountName,dateOpened,ClientId")] SavingsAccounts savingsAccounts)
        {
            if (ModelState.IsValid)
            {
                _context.Add(savingsAccounts);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ClientId"] = new SelectList(_context.Client, "ClientID", "ClientID", savingsAccounts.ClientId);
            return View(savingsAccounts);
        }

        // GET: SavingsAccounts/Edit/5
        [Authorize]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var savingsAccounts = await _context.SavingsAccounts.FindAsync(id);
            if (savingsAccounts == null)
            {
                return NotFound();
            }
            ViewData["ClientId"] = new SelectList(_context.Client, "ClientID", "ClientID", savingsAccounts.ClientId);
            return View(savingsAccounts);
        }

        // POST: SavingsAccounts/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("SavingsAccountsId,savingsAccountName,dateOpened,ClientId")] SavingsAccounts savingsAccounts)
        {
            if (id != savingsAccounts.SavingsAccountsId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(savingsAccounts);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SavingsAccountsExists(savingsAccounts.SavingsAccountsId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ClientId"] = new SelectList(_context.Client, "ClientID", "ClientID", savingsAccounts.ClientId);
            return View(savingsAccounts);
        }

        // GET: SavingsAccounts/Delete/5
        [Authorize]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var savingsAccounts = await _context.SavingsAccounts
                .Include(s => s.client)
                .FirstOrDefaultAsync(m => m.SavingsAccountsId == id);
            if (savingsAccounts == null)
            {
                return NotFound();
            }

            return View(savingsAccounts);
        }

        // POST: SavingsAccounts/Delete/5
        [Authorize]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var savingsAccounts = await _context.SavingsAccounts.FindAsync(id);
            _context.SavingsAccounts.Remove(savingsAccounts);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool SavingsAccountsExists(int id)
        {
            return _context.SavingsAccounts.Any(e => e.SavingsAccountsId == id);
        }
    }
}
